﻿const axios = require("axios");

module.exports = async function(context, req) {
  const org        = process.env.AZDO_ORG;
  const project    = process.env.AZDO_PROJECT;
  const pipelineId = process.env.AZDO_PIPELINE_ID;
  const pat        = process.env.AZDO_PAT;

  const url  = `https://dev.azure.com/${org}/${project}/_apis/pipelines/${pipelineId}/runs?api-version=6.0-preview.1`;
  const auth = Buffer.from(`:${pat}`).toString("base64");

  try {
    await axios.post(url, {}, {
      headers: { Authorization: `Basic ${auth}` }
    });
    context.res = { status: 202, body: "Pipeline queued successfully." };
  } catch (err) {
    context.res = { status: err.response?.status || 500, body: err.message };
  }
};
